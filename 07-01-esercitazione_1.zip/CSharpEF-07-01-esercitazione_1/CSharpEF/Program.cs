﻿/*
1. Creare le classi dalle quali generare il database: Models e DbContext (vedi schema.png)
2. Creare Migrazione
3. Applicare migrazione al database
4. Inserire 1 Location (Transazione 1)
5. Inserire un Torneo che si svolga nella Location appena inserita (Transazione 1)
6. Creare 4 Squadre con almeno 2 Giocatori (Transazione 1)
7. Selezionare tutte le Squadre del DB (Transazione 2)
8. Iscrivere le Squadre di cui sopra al Torneo (Transazione 2)
9. Interrogare il DB per avere le info sul Torneo, compresa la Location (Transazione 3)
10. Interrogare il DB per sapere, a partire dal Torneo di cui sopra, l'elenco delle Squadre iscritte (con data di iscrizione) (Transazione 3)
*/
Console.WriteLine();