﻿// 03-01 INTRODUZIONE
// ADO.NET (ActiveX Data Objects)
// Installazione SqlClient provider nuget
// https://docs.microsoft.com/it-it/dotnet/framework/data/adonet/data-providers

using System.Data;
using System.Data.SqlClient;

var connectionString = @"Server=(localdb)\MSSQLLocalDB;Database=CSharpEF;User Id=sa;Password=sa;";
// https://www.connectionstrings.com/sql-server/

// 03-02 CONNESSIONE
using (SqlConnection connection = new(connectionString))
{
    SqlCommand cmd = connection.CreateCommand();


    try
    {
        connection.Open();

        // 03-03 QUERY
        // scalar
        cmd.CommandText = "SELECT COUNT(*) as count FROM Todos";
        var count = cmd.ExecuteScalar();
        Console.WriteLine("Numero todos: " + count);

        // where
        int userId = 2;
        cmd.CommandText = "SELECT COUNT(*) as count FROM Todos WHERE UtenteId = @UtenteId";
        cmd.Parameters.AddWithValue("@UtenteId", userId);
        count = cmd.ExecuteScalar();
        Console.WriteLine($"Numero todos utente {userId}: {count}");

        //// insert
        //cmd.CommandText = "INSERT INTO Todos VALUES (@testo, 0, 1, 1)";
        //cmd.Parameters.AddWithValue("@testo", "Fatturare");
        //var result = cmd.ExecuteNonQuery();
        //Console.WriteLine($"Risultato inserimento: {result}");

        // 03-04 READER
        cmd.CommandText = "SELECT * FROM Todos";
        SqlDataReader reader = cmd.ExecuteReader();
        while (reader.Read())
        {
            Console.WriteLine($"{reader[0]}\t{reader[1]}\t{reader[2]}");
        }
        reader.Close();
        Console.WriteLine();

        // 03-05 DATASET
        SqlDataAdapter adapter = new SqlDataAdapter(cmd);
        DataSet ds = new DataSet();
        adapter.Fill(ds, "todos");

        foreach (DataRow t in ds.Tables["todos"].Rows)
        {
            Console.WriteLine(t["Testo"]);
        }
        Console.WriteLine();

        var q = @"select t.Id, t.Testo, t.Completato, c.Nome as Categoria, u.Nome as Utente from Todos as t
                inner join Categorie as c on t.CategoriaId = c.Id
                inner join Utenti as u on t.UtenteId = u.Id";

        cmd.CommandText = q;
        adapter.Fill(ds, "todos");

        foreach (DataRow t in ds.Tables["todos"].Rows)
        {
            Console.WriteLine($"{t["Testo"]}\t{t["Categoria"]}\t{t["Utente"]}");
        }
        Console.WriteLine();

        // 03-06 DATASET RELATIONS
        ds = new DataSet();
        cmd.CommandText = "SELECT * FROM Todos";
        adapter.Fill(ds, "todos");
        cmd.CommandText = "SELECT * FROM Categorie";
        adapter.Fill(ds, "categorie");

        DataRelation relation = ds.Relations.Add("TodosCategorie",
                                ds.Tables["categorie"].Columns["Id"],
                                ds.Tables["todos"].Columns["CategoriaId"]);

        foreach (DataRow cRow in ds.Tables["categorie"].Rows)
        {
            Console.WriteLine(cRow["Nome"]);
            foreach (DataRow tRow in cRow.GetChildRows(relation))
                Console.WriteLine("\t" + tRow["Testo"]);
        }
        Console.WriteLine();

        // 03-07 STORED PROCEDURES
        cmd.CommandType = CommandType.StoredProcedure;
        cmd.CommandText = "InsertUserAndTodo";
        cmd.Parameters.Clear();
        cmd.Parameters.AddWithValue("@UtentiNome", "Ginger");
        cmd.Parameters.AddWithValue("@TodosTesto", "Fare la doccia");
        cmd.Parameters.AddWithValue("@TodosCategoriaId", 1);
        cmd.Parameters.Add("@UserId", SqlDbType.Int).Direction = ParameterDirection.Output;
        cmd.Parameters.Add("@TodoId", SqlDbType.Int).Direction = ParameterDirection.Output;
        cmd.ExecuteNonQuery();
        Console.WriteLine($"UserId: {cmd.Parameters["@UserId"].Value}, TodoId: {cmd.Parameters["@TodoId"].Value}");
    }
    catch (Exception ex)
    {
        Console.WriteLine(ex.Message);
    }
}

