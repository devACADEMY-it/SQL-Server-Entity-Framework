﻿CREATE TABLE [dbo].[Categorie](
	[Id] [int] NOT NULL,
	[Nome] [nvarchar](max) NOT NULL,
 CONSTRAINT [PK_Categorie] PRIMARY KEY CLUSTERED 
(
	[Id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Todos](
	[Id] [int] IDENTITY(1,1) NOT NULL,
	[Testo] [varchar](max) NOT NULL,
	[Completato] [bit] NOT NULL,
	[CategoriaId] [int] NOT NULL,
	[UtenteId] [int] NOT NULL,
 CONSTRAINT [PK_Todos] PRIMARY KEY CLUSTERED 
(
	[Id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE VIEW [dbo].[VW_Todos]
AS
SELECT dbo.Todos.*, dbo.Categorie.Nome AS Categoria
FROM     dbo.Todos INNER JOIN
                  dbo.Categorie ON dbo.Todos.CategoriaId = dbo.Categorie.Id
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Utenti](
	[Id] [int] IDENTITY(1,1) NOT NULL,
	[Nome] [nvarchar](max) NOT NULL,
	[Attivo] [bit] NOT NULL,
 CONSTRAINT [PK_Utenti] PRIMARY KEY CLUSTERED 
(
	[Id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO
ALTER TABLE [dbo].[Todos] ADD  CONSTRAINT [DF_Todos_Completato]  DEFAULT ((0)) FOR [Completato]
GO
ALTER TABLE [dbo].[Todos]  WITH CHECK ADD  CONSTRAINT [FK_Todos_Categorie] FOREIGN KEY([CategoriaId])
REFERENCES [dbo].[Categorie] ([Id])
GO
ALTER TABLE [dbo].[Todos] CHECK CONSTRAINT [FK_Todos_Categorie]
GO
ALTER TABLE [dbo].[Todos]  WITH CHECK ADD  CONSTRAINT [FK_Todos_Utenti] FOREIGN KEY([UtenteId])
REFERENCES [dbo].[Utenti] ([Id])
GO
ALTER TABLE [dbo].[Todos] CHECK CONSTRAINT [FK_Todos_Utenti]
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
-- =============================================
-- Author: Matteo Valenzi
-- Create date: 
-- Description:	
-- =============================================
CREATE PROCEDURE [dbo].[InsertUserAndTodo] 
	-- Add the parameters for the stored procedure here
	@UtentiNome nvarchar(MAX) = '', 
	@TodosTesto nvarchar(MAX) = '', 
	@TodosCategoriaId int = 1,
	@UserId int output,
	@TodoId int output
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

	BEGIN TRANSACTION
	BEGIN TRY
		-- Insert statements for procedure here
		INSERT INTO Utenti VALUES (@UtentiNome, 1);
		SET @UserId=SCOPE_IDENTITY();
			
		INSERT INTO Todos VALUES (@TodosTesto, 0, @TodosCategoriaId, @UserId);
		SET @TodoId=SCOPE_IDENTITY();

		COMMIT TRANSACTION
    END TRY
    BEGIN CATCH
            -- if error, roll back any chanegs done by any of the sql statements
            ROLLBACK TRANSACTION
    END CATCH
END
GO
