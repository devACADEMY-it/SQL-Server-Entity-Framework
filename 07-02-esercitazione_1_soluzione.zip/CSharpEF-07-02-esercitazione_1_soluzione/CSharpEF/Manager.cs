﻿using CSharpEF.Models;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CSharpEF
{
    public static class Manager
    {
        public static void GeneraTorneo()
        {
            using (var dc = new TorneiContext())
            {
                var parcoDeiPrincipi = new Location() { Nome = "Parco dei Principi", Indirizzo = "Via Alta, 3 - Modena (MO)" };
                dc.Locations.Add(parcoDeiPrincipi);

                var torneo = new Torneo()
                {
                    Nome = "Estivo 2022",
                    NumeroSquadre = 4,
                    Location = parcoDeiPrincipi,
                    DataInizio = new DateTime(2022, 3, 1),
                };
                dc.Tornei.Add(torneo);

                var italia = new Squadra() { Nome = "Italia" };
                var germania = new Squadra() { Nome = "Germania" };
                var francia = new Squadra() { Nome = "Francia" };
                var olanda = new Squadra() { Nome = "Olanda" };

                // genero 8 giocatori
                for (int i = 0; i < 4 * 2; i++)
                {
                    var g = new Giocatore()
                    {
                        Nome = $"G{i + 1}",
                        DataNascita = Utility.GeneraDataCasuale(),
                        NumeroMaglia = i + 1,
                        Squadra = i < 4 ? italia : germania
                    };
                    dc.Giocatori.Add(g);
                }

                for (int i = 0; i < 4 * 2; i++)
                {
                    var g = new Giocatore()
                    {
                        Nome = $"G{i + 1}",
                        DataNascita = Utility.GeneraDataCasuale(),
                        NumeroMaglia = i + 1,
                        Squadra = i < 4 ? francia : olanda
                    };
                    dc.Giocatori.Add(g);
                }

                try
                {
                    dc.SaveChanges();
                }
                catch (Exception ex)
                {
                    if (ex.InnerException != null)
                    {
                        Console.WriteLine(ex.InnerException.Message);
                    }
                    else
                    {
                        Console.WriteLine(ex.Message);
                    }
                }
            }
        }

        public static void IscriviSquadre()
        {
            using (var dc = new TorneiContext())
            {
                var squadre = dc.Squadre;
                var torneo = dc.Tornei.First();

                foreach (var s in squadre)
                {
                    torneo.Squadre.Add(s);
                }

                try
                {
                    dc.SaveChanges();
                }
                catch (Exception ex)
                {
                    if (ex.InnerException != null)
                    {
                        Console.WriteLine(ex.InnerException.Message);
                    }
                    else
                    {
                        Console.WriteLine(ex.Message);
                    }
                }
            }
        }

        public static void InfoTorneo()
        {
            using (var dc = new TorneiContext())
            {
                 // Argument cannot be used for parameter due to differences in the nullability of reference types.
                var t = dc.Tornei
                    .Include(t => t.Location)
                    .Include(p => p.Prenotazioni).ThenInclude(s => s.Squadra)
                    .First();


                Console.WriteLine($"Torneo {t.Nome} a {t.NumeroSquadre} squadre");
                Console.WriteLine($"Data inizio: {t.DataInizio?.ToShortDateString()}");
                Console.WriteLine($"Luogo: {t.Location?.Nome} {t.Location?.Indirizzo}");
                Console.WriteLine();
                Console.WriteLine("Elenco squadre");

                foreach (var s in t.Prenotazioni)
                {
                    Console.WriteLine($"{s.Squadra?.Nome} iscritta il {s.DataPrenotazione}");
                }

            }
        }
    }
}
