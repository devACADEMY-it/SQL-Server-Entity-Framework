﻿using CSharpEF.Models;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CSharpEF
{
    public class TorneiContext : DbContext
    {
        public DbSet<Torneo> Tornei => Set<Torneo>();
        public DbSet<Location> Locations => Set<Location>();
        public DbSet<Giocatore> Giocatori => Set<Giocatore>();
        public DbSet<Squadra> Squadre => Set<Squadra>();
        public DbSet<Prenotazione> Prenotazioni => Set<Prenotazione>();

        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            if (!optionsBuilder.IsConfigured)
            {
                optionsBuilder.UseSqlServer("Data Source=(localdb)\\MSSQLLocalDB;Initial Catalog=CSharpEF_Tornei;User Id=sa;Password=sa");
            }
        }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<Torneo>()
                .HasMany(s => s.Squadre)
                .WithMany(t => t.Tornei)
                .UsingEntity<Prenotazione>(
                    j => j
                        .HasOne(t => t.Squadra)
                        .WithMany(t => t.Prenotazioni)
                        .HasForeignKey(f => f.SquadraId),
                    j => j
                        .HasOne(a => a.Torneo)
                        .WithMany(a => a.Prenotazioni)
                        .HasForeignKey(f => f.TorneoId),
                    j =>
                    {
                        j.Property(p => p.DataPrenotazione).HasDefaultValueSql("getdate()");
                        j.HasKey(k => new { k.TorneoId, k.SquadraId });
                    });
        }
    }
}
