﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CSharpEF.Models
{
    public class Prenotazione
    {
        public int SquadraId { get; set; }
        public virtual Squadra? Squadra { get; set; }

        public int TorneoId { get; set; }
        public virtual Torneo? Torneo { get; set; }

        [Required]
        public DateTime? DataPrenotazione { get; set; }

    }
}
