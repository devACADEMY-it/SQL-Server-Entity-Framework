﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CSharpEF.Models
{
    public class Location
    {
        public int Id { get; set; }

        [Required]
        [MaxLength(150)]
        public string? Nome { get; set; }

        [Required]
        [MaxLength(250)]
        public string? Indirizzo { get; set; }

        public virtual List<Torneo> Tornei { get; set; } = new List<Torneo>();
    }
}
