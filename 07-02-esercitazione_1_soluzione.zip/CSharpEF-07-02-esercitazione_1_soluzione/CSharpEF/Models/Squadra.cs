﻿using System.ComponentModel.DataAnnotations;

namespace CSharpEF.Models
{
    public class Squadra
    {
        public int Id { get; set; }

        [Required]
        [MaxLength(100)]
        public string? Nome { get; set; }

        public virtual List<Giocatore> Giocatori { get; set; } = new List<Giocatore>();

        public virtual List<Torneo> Tornei { get; set; } = new List<Torneo>();

        public virtual List<Prenotazione> Prenotazioni { get; set; } = new List<Prenotazione>();
    }
}
