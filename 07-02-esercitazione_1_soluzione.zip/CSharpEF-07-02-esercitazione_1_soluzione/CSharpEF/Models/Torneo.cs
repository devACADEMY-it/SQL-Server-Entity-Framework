﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CSharpEF.Models
{
    public class Torneo
    {
        public int Id { get; set; }

        [Required]
        [MaxLength(150)]
        public string? Nome { get; set; }

        [Required]
        public DateTime? DataInizio { get; set; }

        public int NumeroSquadre { get; set; }

        [Required]
        public virtual Location? Location { get; set; }

        public virtual List<Squadra> Squadre { get; set; } = new List<Squadra>();

        public virtual List<Prenotazione> Prenotazioni { get; set; } = new List<Prenotazione>();
    }
}
