﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CSharpEF.Models
{
    public class Giocatore
    {
        public int Id { get; set; }
        
        [Required]
        [MaxLength(100)]
        public string? Nome { get; set; }

        [Required]        
        public int NumeroMaglia { get; set; }

        [Required]
        public DateTime? DataNascita { get; set; }

        [Required]
        public virtual Squadra? Squadra { get; set; }
}
}
