﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CSharpEF
{
    public static class Utility
    {
        public static DateTime GeneraDataCasuale()
        {
            Random r = new Random();
            var min = DateTimeOffset.Now.AddYears(-46).ToUnixTimeSeconds();
            var max = DateTimeOffset.Now.AddYears(-16).ToUnixTimeSeconds();

            return DateTimeOffset.FromUnixTimeSeconds(r.Next((int)min, (int)max)).DateTime;
        }
    }
}
