﻿using CSharpEF;
using CSharpEF.Models;

// 05-01 CREAZIONE MODELLI
// Cartella Models + BlogContext

// 05-02 MIGRAZIONI
// 1. creazione migrazione
// dotnet ef migrations add InitialCreate --context BlogContext
// 2. aggiornamento database
// dotnet ef database update --context BlogContext

// 05-03 ANNOTAZIONI 1
// 1. creazione migrazione
// dotnet ef migrations add DataAnnotations --context BlogContext
// 2. aggiornamento database
// dotnet ef database update --context BlogContext


// 05-04 ANNOTAZIONI 2
// Modelli Prodotto e CategoriaProdotto (aggiungere al Context)
// 1. creazione migrazione
// dotnet ef migrations add Prodotti --context BlogContext
// 2. aggiornamento database
// dotnet ef database update --context BlogContext

// 05-05 RIMUOVERE MIGRAZIONE 
// 1. aggiornamento database
// dotnet ef database update DataAnnotations --context BlogContext
// 2. rimozione migration
// dotnet ef migrations list
// dotnet ef migrations remove
// commentare BlogContext

// 06-06 NAVIGATION PROPERTIES
// Inserire dati a DB
using (var dc = new BlogContext())
{
    var art = dc.Articoli.First();
    Console.WriteLine(art.Titolo);
    Console.WriteLine(art.Autore!.Nome);

    // shadow property
    Console.WriteLine(dc.Entry(art).Property("AutoreId").CurrentValue);

    var autore = dc.Utenti.First();
    if (autore.Articoli!.Any())
    {
        Console.WriteLine(autore.Articoli!.Last().Titolo);
    }
    Console.WriteLine();
}

// 06-07 RELAZIONE MOLTI A MOLTI
// Categoria.cs
// 1. creazione migrazione
// dotnet ef migrations add ArticoliCategorie
// 2. aggiornamento database
// dotnet ef database update
// Inserire dati a DB
using (var dc = new BlogContext())
{
    var art = dc.Articoli.First();
    Console.WriteLine(art.Categorie.First().Nome);

    var cat = dc.Categorie.First();
    Console.WriteLine(cat.Articoli.First().Titolo);
}

// 06-08 APPROCCIO FLUENT 1
// Tag.cs, Articolo.cs, BlogContext.cs
// 1. creazione migrazione
// dotnet ef migrations add ArticoliTags
// 2. aggiornamento database
// dotnet ef database update

Console.ReadKey();
