﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CSharpEF
{
    public static class DBInitializer
    {
        public static void Initialize(BlogContext dc)
        {
            if (dc.Categorie.Any()
                && dc.Utenti.Any()
                && dc.Articoli.Any()
                && dc.Commenti.Any())
            {
                return;   // DB già inizializzato
            }
        }
    }
}
