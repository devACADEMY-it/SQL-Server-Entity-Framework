﻿using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

// 05-04 ANNOTAZIONI 2
namespace CSharpEF.Models
{
    public class Prodotto
    {
        [Key]
        [Column(TypeName = "nchar(10)", Order = 0)]
        public string? Codice { get; set; }

        [Required]
        [MaxLength(100)]
        [Column(Order = 1)]
        public string? Nome { get; set; }

        [Required]
        [Column("Descrizione", Order =2, TypeName = "nvarchar(200)")]
        public string? Testo { get; set; }

        [Comment("Prodotto a magazzino")]
        [Column(Order = 4)]
        public bool Attivo { get; set; }

        [Precision(14, 2)]
        [Column(Order = 3)]
        public decimal Punteggio { get; set; }

        [Required]
        [Column(Order = 6)]
        public DateTime DataCreazione { get; set; }

        [Required]
        [Column(Order = 5)]
        public virtual CategoriaProdotto? Categoria { get; set; }

    }

    [Table("CategoriaProdottoCustom")]
    public class CategoriaProdotto
    {
        [DatabaseGenerated(DatabaseGeneratedOption.None)]
        public int Id { get; set; }

        [Required]
        [MaxLength(100)]        
        public string? Nome { get; set; }
    }
}
