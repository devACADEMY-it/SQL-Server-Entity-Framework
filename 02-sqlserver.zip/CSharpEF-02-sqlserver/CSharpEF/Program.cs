﻿// 02-02 CREAZIONE DB
// CSharpEF.sql

// 02-05 BACKUP/RESTORE
// C:\Users\dillo\AppData\Local\Microsoft\Microsoft SQL Server Local DB\Instances\mssqllocaldb

Console.WriteLine("Hello, World!");
