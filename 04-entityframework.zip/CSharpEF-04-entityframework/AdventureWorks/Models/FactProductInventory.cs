﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using Microsoft.EntityFrameworkCore;

namespace AdventureWorks.Models
{
    [Table("FactProductInventory")]
    public partial class FactProductInventory
    {
        [Key]
        public int ProductKey { get; set; }
        [Key]
        public int DateKey { get; set; }
        [Column(TypeName = "date")]
        public DateTime MovementDate { get; set; }
        [Column(TypeName = "money")]
        public decimal UnitCost { get; set; }
        public int UnitsIn { get; set; }
        public int UnitsOut { get; set; }
        public int UnitsBalance { get; set; }

        [ForeignKey("DateKey")]
        [InverseProperty("FactProductInventories")]
        public virtual DimDate DateKeyNavigation { get; set; } = null!;
        [ForeignKey("ProductKey")]
        [InverseProperty("FactProductInventories")]
        public virtual DimProduct ProductKeyNavigation { get; set; } = null!;
    }
}
