﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using Microsoft.EntityFrameworkCore;

namespace AdventureWorks.Models
{
    [Table("DimReseller")]
    [Index("ResellerAlternateKey", Name = "AK_DimReseller_ResellerAlternateKey", IsUnique = true)]
    public partial class DimReseller
    {
        public DimReseller()
        {
            FactResellerSales = new HashSet<FactResellerSale>();
        }

        [Key]
        public int ResellerKey { get; set; }
        public int? GeographyKey { get; set; }
        [StringLength(15)]
        public string? ResellerAlternateKey { get; set; }
        [StringLength(25)]
        public string? Phone { get; set; }
        [StringLength(20)]
        [Unicode(false)]
        public string BusinessType { get; set; } = null!;
        [StringLength(50)]
        public string ResellerName { get; set; } = null!;
        public int? NumberEmployees { get; set; }
        [StringLength(1)]
        [Unicode(false)]
        public string? OrderFrequency { get; set; }
        public byte? OrderMonth { get; set; }
        public int? FirstOrderYear { get; set; }
        public int? LastOrderYear { get; set; }
        [StringLength(50)]
        public string? ProductLine { get; set; }
        [StringLength(60)]
        public string? AddressLine1 { get; set; }
        [StringLength(60)]
        public string? AddressLine2 { get; set; }
        [Column(TypeName = "money")]
        public decimal? AnnualSales { get; set; }
        [StringLength(50)]
        public string? BankName { get; set; }
        public byte? MinPaymentType { get; set; }
        [Column(TypeName = "money")]
        public decimal? MinPaymentAmount { get; set; }
        [Column(TypeName = "money")]
        public decimal? AnnualRevenue { get; set; }
        public int? YearOpened { get; set; }

        [ForeignKey("GeographyKey")]
        [InverseProperty("DimResellers")]
        public virtual DimGeography? GeographyKeyNavigation { get; set; }
        [InverseProperty("ResellerKeyNavigation")]
        public virtual ICollection<FactResellerSale> FactResellerSales { get; set; }
    }
}
