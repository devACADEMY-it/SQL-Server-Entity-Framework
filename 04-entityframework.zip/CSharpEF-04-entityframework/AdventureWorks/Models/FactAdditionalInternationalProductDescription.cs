﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using Microsoft.EntityFrameworkCore;

namespace AdventureWorks.Models
{
    [Table("FactAdditionalInternationalProductDescription")]
    public partial class FactAdditionalInternationalProductDescription
    {
        [Key]
        public int ProductKey { get; set; }
        [Key]
        [StringLength(50)]
        public string CultureName { get; set; } = null!;
        public string ProductDescription { get; set; } = null!;
    }
}
