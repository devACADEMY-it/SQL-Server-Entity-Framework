﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using Microsoft.EntityFrameworkCore;

namespace AdventureWorks.Models
{
    [Table("DimSalesReason")]
    public partial class DimSalesReason
    {
        public DimSalesReason()
        {
            SalesOrders = new HashSet<FactInternetSale>();
        }

        [Key]
        public int SalesReasonKey { get; set; }
        public int SalesReasonAlternateKey { get; set; }
        [StringLength(50)]
        public string SalesReasonName { get; set; } = null!;
        [StringLength(50)]
        public string SalesReasonReasonType { get; set; } = null!;

        [ForeignKey("SalesReasonKey")]
        [InverseProperty("SalesReasonKeys")]
        public virtual ICollection<FactInternetSale> SalesOrders { get; set; }
    }
}
