﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using Microsoft.EntityFrameworkCore;

namespace AdventureWorks.Models
{
    public partial class FactInternetSale
    {
        public FactInternetSale()
        {
            SalesReasonKeys = new HashSet<DimSalesReason>();
        }

        public int ProductKey { get; set; }
        public int OrderDateKey { get; set; }
        public int DueDateKey { get; set; }
        public int ShipDateKey { get; set; }
        public int CustomerKey { get; set; }
        public int PromotionKey { get; set; }
        public int CurrencyKey { get; set; }
        public int SalesTerritoryKey { get; set; }
        [Key]
        [StringLength(20)]
        public string SalesOrderNumber { get; set; } = null!;
        [Key]
        public byte SalesOrderLineNumber { get; set; }
        public byte RevisionNumber { get; set; }
        public short OrderQuantity { get; set; }
        [Column(TypeName = "money")]
        public decimal UnitPrice { get; set; }
        [Column(TypeName = "money")]
        public decimal ExtendedAmount { get; set; }
        public double UnitPriceDiscountPct { get; set; }
        public double DiscountAmount { get; set; }
        [Column(TypeName = "money")]
        public decimal ProductStandardCost { get; set; }
        [Column(TypeName = "money")]
        public decimal TotalProductCost { get; set; }
        [Column(TypeName = "money")]
        public decimal SalesAmount { get; set; }
        [Column(TypeName = "money")]
        public decimal TaxAmt { get; set; }
        [Column(TypeName = "money")]
        public decimal Freight { get; set; }
        [StringLength(25)]
        public string? CarrierTrackingNumber { get; set; }
        [Column("CustomerPONumber")]
        [StringLength(25)]
        public string? CustomerPonumber { get; set; }
        [Column(TypeName = "datetime")]
        public DateTime? OrderDate { get; set; }
        [Column(TypeName = "datetime")]
        public DateTime? DueDate { get; set; }
        [Column(TypeName = "datetime")]
        public DateTime? ShipDate { get; set; }

        [ForeignKey("CurrencyKey")]
        [InverseProperty("FactInternetSales")]
        public virtual DimCurrency CurrencyKeyNavigation { get; set; } = null!;
        [ForeignKey("CustomerKey")]
        [InverseProperty("FactInternetSales")]
        public virtual DimCustomer CustomerKeyNavigation { get; set; } = null!;
        [ForeignKey("DueDateKey")]
        [InverseProperty("FactInternetSaleDueDateKeyNavigations")]
        public virtual DimDate DueDateKeyNavigation { get; set; } = null!;
        [ForeignKey("OrderDateKey")]
        [InverseProperty("FactInternetSaleOrderDateKeyNavigations")]
        public virtual DimDate OrderDateKeyNavigation { get; set; } = null!;
        [ForeignKey("ProductKey")]
        [InverseProperty("FactInternetSales")]
        public virtual DimProduct ProductKeyNavigation { get; set; } = null!;
        [ForeignKey("PromotionKey")]
        [InverseProperty("FactInternetSales")]
        public virtual DimPromotion PromotionKeyNavigation { get; set; } = null!;
        [ForeignKey("SalesTerritoryKey")]
        [InverseProperty("FactInternetSales")]
        public virtual DimSalesTerritory SalesTerritoryKeyNavigation { get; set; } = null!;
        [ForeignKey("ShipDateKey")]
        [InverseProperty("FactInternetSaleShipDateKeyNavigations")]
        public virtual DimDate ShipDateKeyNavigation { get; set; } = null!;

        [ForeignKey("SalesOrderNumber,SalesOrderLineNumber")]
        [InverseProperty("SalesOrders")]
        public virtual ICollection<DimSalesReason> SalesReasonKeys { get; set; }
    }
}
