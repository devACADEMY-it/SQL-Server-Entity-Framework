﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using Microsoft.EntityFrameworkCore;

namespace AdventureWorks.Models
{
    [Table("DimProductCategory")]
    [Index("ProductCategoryAlternateKey", Name = "AK_DimProductCategory_ProductCategoryAlternateKey", IsUnique = true)]
    public partial class DimProductCategory
    {
        public DimProductCategory()
        {
            DimProductSubcategories = new HashSet<DimProductSubcategory>();
        }

        [Key]
        public int ProductCategoryKey { get; set; }
        public int? ProductCategoryAlternateKey { get; set; }
        [StringLength(50)]
        public string EnglishProductCategoryName { get; set; } = null!;
        [StringLength(50)]
        public string SpanishProductCategoryName { get; set; } = null!;
        [StringLength(50)]
        public string FrenchProductCategoryName { get; set; } = null!;

        [InverseProperty("ProductCategoryKeyNavigation")]
        public virtual ICollection<DimProductSubcategory> DimProductSubcategories { get; set; }
    }
}
