﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using Microsoft.EntityFrameworkCore;

namespace AdventureWorks.Models
{
    [Table("DimProduct")]
    [Index("ProductAlternateKey", "StartDate", Name = "AK_DimProduct_ProductAlternateKey_StartDate", IsUnique = true)]
    public partial class DimProduct
    {
        public DimProduct()
        {
            FactInternetSales = new HashSet<FactInternetSale>();
            FactProductInventories = new HashSet<FactProductInventory>();
            FactResellerSales = new HashSet<FactResellerSale>();
        }

        [Key]
        public int ProductKey { get; set; }
        [StringLength(25)]
        public string? ProductAlternateKey { get; set; }
        public int? ProductSubcategoryKey { get; set; }
        [StringLength(3)]
        public string? WeightUnitMeasureCode { get; set; }
        [StringLength(3)]
        public string? SizeUnitMeasureCode { get; set; }
        [StringLength(50)]
        public string EnglishProductName { get; set; } = null!;
        [StringLength(50)]
        public string SpanishProductName { get; set; } = null!;
        [StringLength(50)]
        public string FrenchProductName { get; set; } = null!;
        [Column(TypeName = "money")]
        public decimal? StandardCost { get; set; }
        public bool FinishedGoodsFlag { get; set; }
        [StringLength(15)]
        public string Color { get; set; } = null!;
        public short? SafetyStockLevel { get; set; }
        public short? ReorderPoint { get; set; }
        [Column(TypeName = "money")]
        public decimal? ListPrice { get; set; }
        [StringLength(50)]
        public string? Size { get; set; }
        [StringLength(50)]
        public string? SizeRange { get; set; }
        public double? Weight { get; set; }
        public int? DaysToManufacture { get; set; }
        [StringLength(2)]
        public string? ProductLine { get; set; }
        [Column(TypeName = "money")]
        public decimal? DealerPrice { get; set; }
        [StringLength(2)]
        public string? Class { get; set; }
        [StringLength(2)]
        public string? Style { get; set; }
        [StringLength(50)]
        public string? ModelName { get; set; }
        public byte[]? LargePhoto { get; set; }
        [StringLength(400)]
        public string? EnglishDescription { get; set; }
        [StringLength(400)]
        public string? FrenchDescription { get; set; }
        [StringLength(400)]
        public string? ChineseDescription { get; set; }
        [StringLength(400)]
        public string? ArabicDescription { get; set; }
        [StringLength(400)]
        public string? HebrewDescription { get; set; }
        [StringLength(400)]
        public string? ThaiDescription { get; set; }
        [StringLength(400)]
        public string? GermanDescription { get; set; }
        [StringLength(400)]
        public string? JapaneseDescription { get; set; }
        [StringLength(400)]
        public string? TurkishDescription { get; set; }
        [Column(TypeName = "datetime")]
        public DateTime? StartDate { get; set; }
        [Column(TypeName = "datetime")]
        public DateTime? EndDate { get; set; }
        [StringLength(7)]
        public string? Status { get; set; }

        [ForeignKey("ProductSubcategoryKey")]
        [InverseProperty("DimProducts")]
        public virtual DimProductSubcategory? ProductSubcategoryKeyNavigation { get; set; }
        [InverseProperty("ProductKeyNavigation")]
        public virtual ICollection<FactInternetSale> FactInternetSales { get; set; }
        [InverseProperty("ProductKeyNavigation")]
        public virtual ICollection<FactProductInventory> FactProductInventories { get; set; }
        [InverseProperty("ProductKeyNavigation")]
        public virtual ICollection<FactResellerSale> FactResellerSales { get; set; }
    }
}
