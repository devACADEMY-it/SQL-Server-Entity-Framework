﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using Microsoft.EntityFrameworkCore;

namespace AdventureWorks.Models
{
    [Keyless]
    [Table("AdventureWorksDWBuildVersion")]
    public partial class AdventureWorksDwbuildVersion
    {
        [Column("DBVersion")]
        [StringLength(50)]
        public string? Dbversion { get; set; }
        [Column(TypeName = "datetime")]
        public DateTime? VersionDate { get; set; }
    }
}
