﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using Microsoft.EntityFrameworkCore;

namespace AdventureWorks.Models
{
    [Table("FactCurrencyRate")]
    public partial class FactCurrencyRate
    {
        [Key]
        public int CurrencyKey { get; set; }
        [Key]
        public int DateKey { get; set; }
        public double AverageRate { get; set; }
        public double EndOfDayRate { get; set; }
        [Column(TypeName = "datetime")]
        public DateTime? Date { get; set; }

        [ForeignKey("CurrencyKey")]
        [InverseProperty("FactCurrencyRates")]
        public virtual DimCurrency CurrencyKeyNavigation { get; set; } = null!;
        [ForeignKey("DateKey")]
        [InverseProperty("FactCurrencyRates")]
        public virtual DimDate DateKeyNavigation { get; set; } = null!;
    }
}
