﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using Microsoft.EntityFrameworkCore;

namespace AdventureWorks.Models
{
    [Table("DimProductSubcategory")]
    [Index("ProductSubcategoryAlternateKey", Name = "AK_DimProductSubcategory_ProductSubcategoryAlternateKey", IsUnique = true)]
    public partial class DimProductSubcategory
    {
        public DimProductSubcategory()
        {
            DimProducts = new HashSet<DimProduct>();
        }

        [Key]
        public int ProductSubcategoryKey { get; set; }
        public int? ProductSubcategoryAlternateKey { get; set; }
        [StringLength(50)]
        public string EnglishProductSubcategoryName { get; set; } = null!;
        [StringLength(50)]
        public string SpanishProductSubcategoryName { get; set; } = null!;
        [StringLength(50)]
        public string FrenchProductSubcategoryName { get; set; } = null!;
        public int? ProductCategoryKey { get; set; }

        [ForeignKey("ProductCategoryKey")]
        [InverseProperty("DimProductSubcategories")]
        public virtual DimProductCategory? ProductCategoryKeyNavigation { get; set; }
        [InverseProperty("ProductSubcategoryKeyNavigation")]
        public virtual ICollection<DimProduct> DimProducts { get; set; }
    }
}
