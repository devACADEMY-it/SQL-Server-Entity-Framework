﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using Microsoft.EntityFrameworkCore;

namespace AdventureWorks.Models
{
    [Table("DimSalesTerritory")]
    [Index("SalesTerritoryAlternateKey", Name = "AK_DimSalesTerritory_SalesTerritoryAlternateKey", IsUnique = true)]
    public partial class DimSalesTerritory
    {
        public DimSalesTerritory()
        {
            DimEmployees = new HashSet<DimEmployee>();
            DimGeographies = new HashSet<DimGeography>();
            FactInternetSales = new HashSet<FactInternetSale>();
            FactResellerSales = new HashSet<FactResellerSale>();
        }

        [Key]
        public int SalesTerritoryKey { get; set; }
        public int? SalesTerritoryAlternateKey { get; set; }
        [StringLength(50)]
        public string SalesTerritoryRegion { get; set; } = null!;
        [StringLength(50)]
        public string SalesTerritoryCountry { get; set; } = null!;
        [StringLength(50)]
        public string? SalesTerritoryGroup { get; set; }
        public byte[]? SalesTerritoryImage { get; set; }

        [InverseProperty("SalesTerritoryKeyNavigation")]
        public virtual ICollection<DimEmployee> DimEmployees { get; set; }
        [InverseProperty("SalesTerritoryKeyNavigation")]
        public virtual ICollection<DimGeography> DimGeographies { get; set; }
        [InverseProperty("SalesTerritoryKeyNavigation")]
        public virtual ICollection<FactInternetSale> FactInternetSales { get; set; }
        [InverseProperty("SalesTerritoryKeyNavigation")]
        public virtual ICollection<FactResellerSale> FactResellerSales { get; set; }
    }
}
