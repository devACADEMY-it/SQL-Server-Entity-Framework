﻿using System;
using System.Collections.Generic;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata;
using AdventureWorks.Models;

// 04-04 PROGETTO DATI: ADVENTUREWORKS
namespace AdventureWorks
{
    public partial class AdventureWorksDW2019Context : DbContext
    {
        public AdventureWorksDW2019Context()
        {
        }

        public AdventureWorksDW2019Context(DbContextOptions<AdventureWorksDW2019Context> options)
            : base(options)
        {
        }

        public virtual DbSet<AdventureWorksDwbuildVersion> AdventureWorksDwbuildVersions { get; set; } = null!;
        public virtual DbSet<DatabaseLog> DatabaseLogs { get; set; } = null!;
        public virtual DbSet<DimAccount> DimAccounts { get; set; } = null!;
        public virtual DbSet<DimCurrency> DimCurrencies { get; set; } = null!;
        public virtual DbSet<DimCustomer> DimCustomers { get; set; } = null!;
        public virtual DbSet<DimDate> DimDates { get; set; } = null!;
        public virtual DbSet<DimDepartmentGroup> DimDepartmentGroups { get; set; } = null!;
        public virtual DbSet<DimEmployee> DimEmployees { get; set; } = null!;
        public virtual DbSet<DimGeography> DimGeographies { get; set; } = null!;
        public virtual DbSet<DimOrganization> DimOrganizations { get; set; } = null!;
        public virtual DbSet<DimProduct> DimProducts { get; set; } = null!;
        public virtual DbSet<DimProductCategory> DimProductCategories { get; set; } = null!;
        public virtual DbSet<DimProductSubcategory> DimProductSubcategories { get; set; } = null!;
        public virtual DbSet<DimPromotion> DimPromotions { get; set; } = null!;
        public virtual DbSet<DimReseller> DimResellers { get; set; } = null!;
        public virtual DbSet<DimSalesReason> DimSalesReasons { get; set; } = null!;
        public virtual DbSet<DimSalesTerritory> DimSalesTerritories { get; set; } = null!;
        public virtual DbSet<DimScenario> DimScenarios { get; set; } = null!;
        public virtual DbSet<FactAdditionalInternationalProductDescription> FactAdditionalInternationalProductDescriptions { get; set; } = null!;
        public virtual DbSet<FactCallCenter> FactCallCenters { get; set; } = null!;
        public virtual DbSet<FactCurrencyRate> FactCurrencyRates { get; set; } = null!;
        public virtual DbSet<FactFinance> FactFinances { get; set; } = null!;
        public virtual DbSet<FactInternetSale> FactInternetSales { get; set; } = null!;
        public virtual DbSet<FactProductInventory> FactProductInventories { get; set; } = null!;
        public virtual DbSet<FactResellerSale> FactResellerSales { get; set; } = null!;
        public virtual DbSet<FactSalesQuotum> FactSalesQuota { get; set; } = null!;
        public virtual DbSet<FactSurveyResponse> FactSurveyResponses { get; set; } = null!;
        public virtual DbSet<NewFactCurrencyRate> NewFactCurrencyRates { get; set; } = null!;
        public virtual DbSet<ProspectiveBuyer> ProspectiveBuyers { get; set; } = null!;
        public virtual DbSet<VAssocSeqLineItem> VAssocSeqLineItems { get; set; } = null!;
        public virtual DbSet<VAssocSeqOrder> VAssocSeqOrders { get; set; } = null!;
        public virtual DbSet<VDmprep> VDmpreps { get; set; } = null!;
        public virtual DbSet<VTargetMail> VTargetMails { get; set; } = null!;
        public virtual DbSet<VTimeSeries> VTimeSeries { get; set; } = null!;

        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            if (!optionsBuilder.IsConfigured)
            {
#warning To protect potentially sensitive information in your connection string, you should move it out of source code. You can avoid scaffolding the connection string by using the Name= syntax to read it from configuration - see https://go.microsoft.com/fwlink/?linkid=2131148. For more guidance on storing connection strings, see http://go.microsoft.com/fwlink/?LinkId=723263.
                optionsBuilder.UseLazyLoadingProxies().UseSqlServer("Data Source=(localdb)\\MSSQLLocalDB;Initial Catalog=AdventureWorksDW2019;User Id=sa;Password=sa");
            }
        }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<DatabaseLog>(entity =>
            {
                entity.HasKey(e => e.DatabaseLogId)
                    .HasName("PK_DatabaseLog_DatabaseLogID")
                    .IsClustered(false);
            });

            modelBuilder.Entity<DimAccount>(entity =>
            {
                entity.HasOne(d => d.ParentAccountKeyNavigation)
                    .WithMany(p => p.InverseParentAccountKeyNavigation)
                    .HasForeignKey(d => d.ParentAccountKey)
                    .HasConstraintName("FK_DimAccount_DimAccount");
            });

            modelBuilder.Entity<DimCurrency>(entity =>
            {
                entity.HasKey(e => e.CurrencyKey)
                    .HasName("PK_DimCurrency_CurrencyKey");

                entity.Property(e => e.CurrencyAlternateKey).IsFixedLength();
            });

            modelBuilder.Entity<DimCustomer>(entity =>
            {
                entity.HasKey(e => e.CustomerKey)
                    .HasName("PK_DimCustomer_CustomerKey");

                entity.Property(e => e.HouseOwnerFlag).IsFixedLength();

                entity.Property(e => e.MaritalStatus).IsFixedLength();

                entity.HasOne(d => d.GeographyKeyNavigation)
                    .WithMany(p => p.DimCustomers)
                    .HasForeignKey(d => d.GeographyKey)
                    .HasConstraintName("FK_DimCustomer_DimGeography");
            });

            modelBuilder.Entity<DimDate>(entity =>
            {
                entity.HasKey(e => e.DateKey)
                    .HasName("PK_DimDate_DateKey");

                entity.Property(e => e.DateKey).ValueGeneratedNever();
            });

            modelBuilder.Entity<DimDepartmentGroup>(entity =>
            {
                entity.HasOne(d => d.ParentDepartmentGroupKeyNavigation)
                    .WithMany(p => p.InverseParentDepartmentGroupKeyNavigation)
                    .HasForeignKey(d => d.ParentDepartmentGroupKey)
                    .HasConstraintName("FK_DimDepartmentGroup_DimDepartmentGroup");
            });

            modelBuilder.Entity<DimEmployee>(entity =>
            {
                entity.HasKey(e => e.EmployeeKey)
                    .HasName("PK_DimEmployee_EmployeeKey");

                entity.Property(e => e.Gender).IsFixedLength();

                entity.Property(e => e.MaritalStatus).IsFixedLength();

                entity.HasOne(d => d.ParentEmployeeKeyNavigation)
                    .WithMany(p => p.InverseParentEmployeeKeyNavigation)
                    .HasForeignKey(d => d.ParentEmployeeKey)
                    .HasConstraintName("FK_DimEmployee_DimEmployee");

                entity.HasOne(d => d.SalesTerritoryKeyNavigation)
                    .WithMany(p => p.DimEmployees)
                    .HasForeignKey(d => d.SalesTerritoryKey)
                    .HasConstraintName("FK_DimEmployee_DimSalesTerritory");
            });

            modelBuilder.Entity<DimGeography>(entity =>
            {
                entity.HasKey(e => e.GeographyKey)
                    .HasName("PK_DimGeography_GeographyKey");

                entity.HasOne(d => d.SalesTerritoryKeyNavigation)
                    .WithMany(p => p.DimGeographies)
                    .HasForeignKey(d => d.SalesTerritoryKey)
                    .HasConstraintName("FK_DimGeography_DimSalesTerritory");
            });

            modelBuilder.Entity<DimOrganization>(entity =>
            {
                entity.HasOne(d => d.CurrencyKeyNavigation)
                    .WithMany(p => p.DimOrganizations)
                    .HasForeignKey(d => d.CurrencyKey)
                    .HasConstraintName("FK_DimOrganization_DimCurrency");

                entity.HasOne(d => d.ParentOrganizationKeyNavigation)
                    .WithMany(p => p.InverseParentOrganizationKeyNavigation)
                    .HasForeignKey(d => d.ParentOrganizationKey)
                    .HasConstraintName("FK_DimOrganization_DimOrganization");
            });

            modelBuilder.Entity<DimProduct>(entity =>
            {
                entity.HasKey(e => e.ProductKey)
                    .HasName("PK_DimProduct_ProductKey");

                entity.Property(e => e.Class).IsFixedLength();

                entity.Property(e => e.ProductLine).IsFixedLength();

                entity.Property(e => e.SizeUnitMeasureCode).IsFixedLength();

                entity.Property(e => e.Style).IsFixedLength();

                entity.Property(e => e.WeightUnitMeasureCode).IsFixedLength();

                entity.HasOne(d => d.ProductSubcategoryKeyNavigation)
                    .WithMany(p => p.DimProducts)
                    .HasForeignKey(d => d.ProductSubcategoryKey)
                    .HasConstraintName("FK_DimProduct_DimProductSubcategory");
            });

            modelBuilder.Entity<DimProductCategory>(entity =>
            {
                entity.HasKey(e => e.ProductCategoryKey)
                    .HasName("PK_DimProductCategory_ProductCategoryKey");
            });

            modelBuilder.Entity<DimProductSubcategory>(entity =>
            {
                entity.HasKey(e => e.ProductSubcategoryKey)
                    .HasName("PK_DimProductSubcategory_ProductSubcategoryKey");

                entity.HasOne(d => d.ProductCategoryKeyNavigation)
                    .WithMany(p => p.DimProductSubcategories)
                    .HasForeignKey(d => d.ProductCategoryKey)
                    .HasConstraintName("FK_DimProductSubcategory_DimProductCategory");
            });

            modelBuilder.Entity<DimPromotion>(entity =>
            {
                entity.HasKey(e => e.PromotionKey)
                    .HasName("PK_DimPromotion_PromotionKey");
            });

            modelBuilder.Entity<DimReseller>(entity =>
            {
                entity.HasKey(e => e.ResellerKey)
                    .HasName("PK_DimReseller_ResellerKey");

                entity.Property(e => e.OrderFrequency).IsFixedLength();

                entity.HasOne(d => d.GeographyKeyNavigation)
                    .WithMany(p => p.DimResellers)
                    .HasForeignKey(d => d.GeographyKey)
                    .HasConstraintName("FK_DimReseller_DimGeography");
            });

            modelBuilder.Entity<DimSalesReason>(entity =>
            {
                entity.HasKey(e => e.SalesReasonKey)
                    .HasName("PK_DimSalesReason_SalesReasonKey");
            });

            modelBuilder.Entity<DimSalesTerritory>(entity =>
            {
                entity.HasKey(e => e.SalesTerritoryKey)
                    .HasName("PK_DimSalesTerritory_SalesTerritoryKey");
            });

            modelBuilder.Entity<FactAdditionalInternationalProductDescription>(entity =>
            {
                entity.HasKey(e => new { e.ProductKey, e.CultureName })
                    .HasName("PK_FactAdditionalInternationalProductDescription_ProductKey_CultureName");
            });

            modelBuilder.Entity<FactCallCenter>(entity =>
            {
                entity.HasOne(d => d.DateKeyNavigation)
                    .WithMany(p => p.FactCallCenters)
                    .HasForeignKey(d => d.DateKey)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_FactCallCenter_DimDate");
            });

            modelBuilder.Entity<FactCurrencyRate>(entity =>
            {
                entity.HasKey(e => new { e.CurrencyKey, e.DateKey })
                    .HasName("PK_FactCurrencyRate_CurrencyKey_DateKey");

                entity.HasOne(d => d.CurrencyKeyNavigation)
                    .WithMany(p => p.FactCurrencyRates)
                    .HasForeignKey(d => d.CurrencyKey)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_FactCurrencyRate_DimCurrency");

                entity.HasOne(d => d.DateKeyNavigation)
                    .WithMany(p => p.FactCurrencyRates)
                    .HasForeignKey(d => d.DateKey)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_FactCurrencyRate_DimDate");
            });

            modelBuilder.Entity<FactFinance>(entity =>
            {
                entity.Property(e => e.FinanceKey).ValueGeneratedOnAdd();

                entity.HasOne(d => d.AccountKeyNavigation)
                    .WithMany()
                    .HasForeignKey(d => d.AccountKey)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_FactFinance_DimAccount");

                entity.HasOne(d => d.DateKeyNavigation)
                    .WithMany()
                    .HasForeignKey(d => d.DateKey)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_FactFinance_DimDate");

                entity.HasOne(d => d.DepartmentGroupKeyNavigation)
                    .WithMany()
                    .HasForeignKey(d => d.DepartmentGroupKey)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_FactFinance_DimDepartmentGroup");

                entity.HasOne(d => d.OrganizationKeyNavigation)
                    .WithMany()
                    .HasForeignKey(d => d.OrganizationKey)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_FactFinance_DimOrganization");

                entity.HasOne(d => d.ScenarioKeyNavigation)
                    .WithMany()
                    .HasForeignKey(d => d.ScenarioKey)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_FactFinance_DimScenario");
            });

            modelBuilder.Entity<FactInternetSale>(entity =>
            {
                entity.HasKey(e => new { e.SalesOrderNumber, e.SalesOrderLineNumber })
                    .HasName("PK_FactInternetSales_SalesOrderNumber_SalesOrderLineNumber");

                entity.HasOne(d => d.CurrencyKeyNavigation)
                    .WithMany(p => p.FactInternetSales)
                    .HasForeignKey(d => d.CurrencyKey)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_FactInternetSales_DimCurrency");

                entity.HasOne(d => d.CustomerKeyNavigation)
                    .WithMany(p => p.FactInternetSales)
                    .HasForeignKey(d => d.CustomerKey)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_FactInternetSales_DimCustomer");

                entity.HasOne(d => d.DueDateKeyNavigation)
                    .WithMany(p => p.FactInternetSaleDueDateKeyNavigations)
                    .HasForeignKey(d => d.DueDateKey)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_FactInternetSales_DimDate1");

                entity.HasOne(d => d.OrderDateKeyNavigation)
                    .WithMany(p => p.FactInternetSaleOrderDateKeyNavigations)
                    .HasForeignKey(d => d.OrderDateKey)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_FactInternetSales_DimDate");

                entity.HasOne(d => d.ProductKeyNavigation)
                    .WithMany(p => p.FactInternetSales)
                    .HasForeignKey(d => d.ProductKey)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_FactInternetSales_DimProduct");

                entity.HasOne(d => d.PromotionKeyNavigation)
                    .WithMany(p => p.FactInternetSales)
                    .HasForeignKey(d => d.PromotionKey)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_FactInternetSales_DimPromotion");

                entity.HasOne(d => d.SalesTerritoryKeyNavigation)
                    .WithMany(p => p.FactInternetSales)
                    .HasForeignKey(d => d.SalesTerritoryKey)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_FactInternetSales_DimSalesTerritory");

                entity.HasOne(d => d.ShipDateKeyNavigation)
                    .WithMany(p => p.FactInternetSaleShipDateKeyNavigations)
                    .HasForeignKey(d => d.ShipDateKey)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_FactInternetSales_DimDate2");

                entity.HasMany(d => d.SalesReasonKeys)
                    .WithMany(p => p.SalesOrders)
                    .UsingEntity<Dictionary<string, object>>(
                        "FactInternetSalesReason",
                        l => l.HasOne<DimSalesReason>().WithMany().HasForeignKey("SalesReasonKey").OnDelete(DeleteBehavior.ClientSetNull).HasConstraintName("FK_FactInternetSalesReason_DimSalesReason"),
                        r => r.HasOne<FactInternetSale>().WithMany().HasForeignKey("SalesOrderNumber", "SalesOrderLineNumber").OnDelete(DeleteBehavior.ClientSetNull).HasConstraintName("FK_FactInternetSalesReason_FactInternetSales"),
                        j =>
                        {
                            j.HasKey("SalesOrderNumber", "SalesOrderLineNumber", "SalesReasonKey").HasName("PK_FactInternetSalesReason_SalesOrderNumber_SalesOrderLineNumber_SalesReasonKey");

                            j.ToTable("FactInternetSalesReason");

                            j.IndexerProperty<string>("SalesOrderNumber").HasMaxLength(20);
                        });
            });

            modelBuilder.Entity<FactProductInventory>(entity =>
            {
                entity.HasKey(e => new { e.ProductKey, e.DateKey });

                entity.HasOne(d => d.DateKeyNavigation)
                    .WithMany(p => p.FactProductInventories)
                    .HasForeignKey(d => d.DateKey)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_FactProductInventory_DimDate");

                entity.HasOne(d => d.ProductKeyNavigation)
                    .WithMany(p => p.FactProductInventories)
                    .HasForeignKey(d => d.ProductKey)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_FactProductInventory_DimProduct");
            });

            modelBuilder.Entity<FactResellerSale>(entity =>
            {
                entity.HasKey(e => new { e.SalesOrderNumber, e.SalesOrderLineNumber })
                    .HasName("PK_FactResellerSales_SalesOrderNumber_SalesOrderLineNumber");

                entity.HasOne(d => d.CurrencyKeyNavigation)
                    .WithMany(p => p.FactResellerSales)
                    .HasForeignKey(d => d.CurrencyKey)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_FactResellerSales_DimCurrency");

                entity.HasOne(d => d.DueDateKeyNavigation)
                    .WithMany(p => p.FactResellerSaleDueDateKeyNavigations)
                    .HasForeignKey(d => d.DueDateKey)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_FactResellerSales_DimDate1");

                entity.HasOne(d => d.EmployeeKeyNavigation)
                    .WithMany(p => p.FactResellerSales)
                    .HasForeignKey(d => d.EmployeeKey)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_FactResellerSales_DimEmployee");

                entity.HasOne(d => d.OrderDateKeyNavigation)
                    .WithMany(p => p.FactResellerSaleOrderDateKeyNavigations)
                    .HasForeignKey(d => d.OrderDateKey)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_FactResellerSales_DimDate");

                entity.HasOne(d => d.ProductKeyNavigation)
                    .WithMany(p => p.FactResellerSales)
                    .HasForeignKey(d => d.ProductKey)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_FactResellerSales_DimProduct");

                entity.HasOne(d => d.PromotionKeyNavigation)
                    .WithMany(p => p.FactResellerSales)
                    .HasForeignKey(d => d.PromotionKey)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_FactResellerSales_DimPromotion");

                entity.HasOne(d => d.ResellerKeyNavigation)
                    .WithMany(p => p.FactResellerSales)
                    .HasForeignKey(d => d.ResellerKey)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_FactResellerSales_DimReseller");

                entity.HasOne(d => d.SalesTerritoryKeyNavigation)
                    .WithMany(p => p.FactResellerSales)
                    .HasForeignKey(d => d.SalesTerritoryKey)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_FactResellerSales_DimSalesTerritory");

                entity.HasOne(d => d.ShipDateKeyNavigation)
                    .WithMany(p => p.FactResellerSaleShipDateKeyNavigations)
                    .HasForeignKey(d => d.ShipDateKey)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_FactResellerSales_DimDate2");
            });

            modelBuilder.Entity<FactSalesQuotum>(entity =>
            {
                entity.HasKey(e => e.SalesQuotaKey)
                    .HasName("PK_FactSalesQuota_SalesQuotaKey");

                entity.HasOne(d => d.DateKeyNavigation)
                    .WithMany(p => p.FactSalesQuota)
                    .HasForeignKey(d => d.DateKey)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_FactSalesQuota_DimDate");

                entity.HasOne(d => d.EmployeeKeyNavigation)
                    .WithMany(p => p.FactSalesQuota)
                    .HasForeignKey(d => d.EmployeeKey)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_FactSalesQuota_DimEmployee");
            });

            modelBuilder.Entity<FactSurveyResponse>(entity =>
            {
                entity.HasKey(e => e.SurveyResponseKey)
                    .HasName("PK_FactSurveyResponse_SurveyResponseKey");

                entity.HasOne(d => d.CustomerKeyNavigation)
                    .WithMany(p => p.FactSurveyResponses)
                    .HasForeignKey(d => d.CustomerKey)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_FactSurveyResponse_CustomerKey");

                entity.HasOne(d => d.DateKeyNavigation)
                    .WithMany(p => p.FactSurveyResponses)
                    .HasForeignKey(d => d.DateKey)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_FactSurveyResponse_DateKey");
            });

            modelBuilder.Entity<ProspectiveBuyer>(entity =>
            {
                entity.HasKey(e => e.ProspectiveBuyerKey)
                    .HasName("PK_ProspectiveBuyer_ProspectiveBuyerKey");

                entity.Property(e => e.HouseOwnerFlag).IsFixedLength();

                entity.Property(e => e.MaritalStatus).IsFixedLength();
            });

            modelBuilder.Entity<VAssocSeqLineItem>(entity =>
            {
                entity.ToView("vAssocSeqLineItems");
            });

            modelBuilder.Entity<VAssocSeqOrder>(entity =>
            {
                entity.ToView("vAssocSeqOrders");
            });

            modelBuilder.Entity<VDmprep>(entity =>
            {
                entity.ToView("vDMPrep");
            });

            modelBuilder.Entity<VTargetMail>(entity =>
            {
                entity.ToView("vTargetMail");

                entity.Property(e => e.HouseOwnerFlag).IsFixedLength();

                entity.Property(e => e.MaritalStatus).IsFixedLength();
            });

            modelBuilder.Entity<VTimeSeries>(entity =>
            {
                entity.ToView("vTimeSeries");
            });

            OnModelCreatingPartial(modelBuilder);
        }

        partial void OnModelCreatingPartial(ModelBuilder modelBuilder);
    }
}
