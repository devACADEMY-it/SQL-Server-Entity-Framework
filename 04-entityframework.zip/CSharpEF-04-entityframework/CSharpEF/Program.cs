﻿using CSharpEF;
using AdventureWorks;

// 04-02 APPROCCIO DB FIRST: SCAFFOLD
// Installazione
// Microsoft.EntityFrameworkCore
// Microsoft.EntityFrameworkCore.Design
// Microsoft.EntityFrameworkCore.SqlServer
// Microsoft.EntityFrameworkCore.Tools

// Scaffold-DbContext -DataAnnotations -OutputDir Models -ContextDir . 'Data Source=(localdb)\MSSQLLocalDB;Initial Catalog=CSharpEF;User Id=sa;Password=sa' Microsoft.EntityFrameworkCore.SqlServer

// 04-03 APPROCCIO DB FIRST: SCAFFOLD
using (var dc = new CSharpEFContext())
{
    foreach (var todo in dc.Todos)
    {
        Console.WriteLine(todo.Testo);
    }
    Console.WriteLine();

    foreach (var cat in dc.Categories)
    {
        Console.WriteLine(cat.Nome);
        foreach (var todo in cat.Todos)
        {
            Console.WriteLine("\t" + todo.Testo);
        }
    }
    Console.WriteLine();
}

// 04-04 PROGETTO DATI: ADVENTUREWORKS
// Creazione Progetto CSharpEF.AdventureWorks
// Microsoft.EntityFrameworkCore.Proxies
// Reference
// Scaffold-DbContext -DataAnnotations -OutputDir Models -ContextDir . 'Data Source=(localdb)\MSSQLLocalDB;Initial Catalog=AdventureWorksDW2019;User Id=sa;Password=sa' Microsoft.EntityFrameworkCore.SqlServer


// 04-05 UTILIZZO PROGETTO DATI
using (var dcAW = new AdventureWorksDW2019Context())
{
    foreach (var subCat in dcAW.DimProductSubcategories.ToList())
    {
        Console.WriteLine($"Cat: {subCat.ProductCategoryKeyNavigation.EnglishProductCategoryName} - SubCat: {subCat.EnglishProductSubcategoryName}");
        foreach (var p in subCat.DimProducts)
        {
            Console.WriteLine("\t" + p.EnglishProductName);
        }

    }
}