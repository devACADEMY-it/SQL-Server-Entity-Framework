﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using Microsoft.EntityFrameworkCore;

namespace CSharpEF.Models
{
    [Table("Categorie")]
    public partial class Categorie
    {
        public Categorie()
        {
            Todos = new HashSet<Todo>();
        }

        [Key]
        public int Id { get; set; }
        [Required]
        public string Nome { get; set; }

        [InverseProperty("Categoria")]
        public virtual ICollection<Todo> Todos { get; set; }
    }
}
