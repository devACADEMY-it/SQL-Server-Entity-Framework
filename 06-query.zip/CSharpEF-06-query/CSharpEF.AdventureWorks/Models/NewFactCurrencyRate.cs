﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using Microsoft.EntityFrameworkCore;

namespace CSharpEF.AdventureWorks.Models
{
    [Keyless]
    [Table("NewFactCurrencyRate")]
    public partial class NewFactCurrencyRate
    {
        public float? AverageRate { get; set; }
        [Column("CurrencyID")]
        [StringLength(3)]
        public string? CurrencyId { get; set; }
        [Column(TypeName = "date")]
        public DateTime? CurrencyDate { get; set; }
        public float? EndOfDayRate { get; set; }
        public int? CurrencyKey { get; set; }
        public int? DateKey { get; set; }
    }
}
