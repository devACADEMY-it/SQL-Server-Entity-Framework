﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using Microsoft.EntityFrameworkCore;

namespace CSharpEF.AdventureWorks.Models
{
    [Table("DatabaseLog")]
    public partial class DatabaseLog
    {
        [Key]
        [Column("DatabaseLogID")]
        public int DatabaseLogId { get; set; }
        [Column(TypeName = "datetime")]
        public DateTime PostTime { get; set; }
        [StringLength(128)]
        public string DatabaseUser { get; set; } = null!;
        [StringLength(128)]
        public string Event { get; set; } = null!;
        [StringLength(128)]
        public string? Schema { get; set; }
        [StringLength(128)]
        public string? Object { get; set; }
        [Column("TSQL")]
        public string Tsql { get; set; } = null!;
        [Column(TypeName = "xml")]
        public string XmlEvent { get; set; } = null!;
    }
}
