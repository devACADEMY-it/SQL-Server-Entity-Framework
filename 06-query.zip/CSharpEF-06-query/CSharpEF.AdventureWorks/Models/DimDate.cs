﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using Microsoft.EntityFrameworkCore;

namespace CSharpEF.AdventureWorks.Models
{
    [Table("DimDate")]
    [Index("FullDateAlternateKey", Name = "AK_DimDate_FullDateAlternateKey", IsUnique = true)]
    public partial class DimDate
    {
        public DimDate()
        {
            FactCallCenters = new HashSet<FactCallCenter>();
            FactCurrencyRates = new HashSet<FactCurrencyRate>();
            FactInternetSaleDueDateKeyNavigations = new HashSet<FactInternetSale>();
            FactInternetSaleOrderDateKeyNavigations = new HashSet<FactInternetSale>();
            FactInternetSaleShipDateKeyNavigations = new HashSet<FactInternetSale>();
            FactProductInventories = new HashSet<FactProductInventory>();
            FactResellerSaleDueDateKeyNavigations = new HashSet<FactResellerSale>();
            FactResellerSaleOrderDateKeyNavigations = new HashSet<FactResellerSale>();
            FactResellerSaleShipDateKeyNavigations = new HashSet<FactResellerSale>();
            FactSalesQuota = new HashSet<FactSalesQuotum>();
            FactSurveyResponses = new HashSet<FactSurveyResponse>();
        }

        [Key]
        public int DateKey { get; set; }
        [Column(TypeName = "date")]
        public DateTime FullDateAlternateKey { get; set; }
        public byte DayNumberOfWeek { get; set; }
        [StringLength(10)]
        public string EnglishDayNameOfWeek { get; set; } = null!;
        [StringLength(10)]
        public string SpanishDayNameOfWeek { get; set; } = null!;
        [StringLength(10)]
        public string FrenchDayNameOfWeek { get; set; } = null!;
        public byte DayNumberOfMonth { get; set; }
        public short DayNumberOfYear { get; set; }
        public byte WeekNumberOfYear { get; set; }
        [StringLength(10)]
        public string EnglishMonthName { get; set; } = null!;
        [StringLength(10)]
        public string SpanishMonthName { get; set; } = null!;
        [StringLength(10)]
        public string FrenchMonthName { get; set; } = null!;
        public byte MonthNumberOfYear { get; set; }
        public byte CalendarQuarter { get; set; }
        public short CalendarYear { get; set; }
        public byte CalendarSemester { get; set; }
        public byte FiscalQuarter { get; set; }
        public short FiscalYear { get; set; }
        public byte FiscalSemester { get; set; }

        [InverseProperty("DateKeyNavigation")]
        public virtual ICollection<FactCallCenter> FactCallCenters { get; set; }
        [InverseProperty("DateKeyNavigation")]
        public virtual ICollection<FactCurrencyRate> FactCurrencyRates { get; set; }
        [InverseProperty("DueDateKeyNavigation")]
        public virtual ICollection<FactInternetSale> FactInternetSaleDueDateKeyNavigations { get; set; }
        [InverseProperty("OrderDateKeyNavigation")]
        public virtual ICollection<FactInternetSale> FactInternetSaleOrderDateKeyNavigations { get; set; }
        [InverseProperty("ShipDateKeyNavigation")]
        public virtual ICollection<FactInternetSale> FactInternetSaleShipDateKeyNavigations { get; set; }
        [InverseProperty("DateKeyNavigation")]
        public virtual ICollection<FactProductInventory> FactProductInventories { get; set; }
        [InverseProperty("DueDateKeyNavigation")]
        public virtual ICollection<FactResellerSale> FactResellerSaleDueDateKeyNavigations { get; set; }
        [InverseProperty("OrderDateKeyNavigation")]
        public virtual ICollection<FactResellerSale> FactResellerSaleOrderDateKeyNavigations { get; set; }
        [InverseProperty("ShipDateKeyNavigation")]
        public virtual ICollection<FactResellerSale> FactResellerSaleShipDateKeyNavigations { get; set; }
        [InverseProperty("DateKeyNavigation")]
        public virtual ICollection<FactSalesQuotum> FactSalesQuota { get; set; }
        [InverseProperty("DateKeyNavigation")]
        public virtual ICollection<FactSurveyResponse> FactSurveyResponses { get; set; }
    }
}
