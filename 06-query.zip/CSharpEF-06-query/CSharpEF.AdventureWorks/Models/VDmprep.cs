﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using Microsoft.EntityFrameworkCore;

namespace CSharpEF.AdventureWorks.Models
{
    [Keyless]
    public partial class VDmprep
    {
        [StringLength(50)]
        public string EnglishProductCategoryName { get; set; } = null!;
        [StringLength(50)]
        public string? Model { get; set; }
        public int CustomerKey { get; set; }
        [StringLength(50)]
        public string? Region { get; set; }
        public int? Age { get; set; }
        [StringLength(8)]
        [Unicode(false)]
        public string IncomeGroup { get; set; } = null!;
        public short CalendarYear { get; set; }
        public short FiscalYear { get; set; }
        public byte Month { get; set; }
        [StringLength(20)]
        public string OrderNumber { get; set; } = null!;
        public byte LineNumber { get; set; }
        public short Quantity { get; set; }
        [Column(TypeName = "money")]
        public decimal Amount { get; set; }
    }
}
