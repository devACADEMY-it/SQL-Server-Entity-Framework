﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using Microsoft.EntityFrameworkCore;

namespace CSharpEF.AdventureWorks.Models
{
    [Table("FactCallCenter")]
    [Index("DateKey", "Shift", Name = "AK_FactCallCenter_DateKey_Shift", IsUnique = true)]
    public partial class FactCallCenter
    {
        [Key]
        [Column("FactCallCenterID")]
        public int FactCallCenterId { get; set; }
        public int DateKey { get; set; }
        [StringLength(15)]
        public string WageType { get; set; } = null!;
        [StringLength(20)]
        public string Shift { get; set; } = null!;
        public short LevelOneOperators { get; set; }
        public short LevelTwoOperators { get; set; }
        public short TotalOperators { get; set; }
        public int Calls { get; set; }
        public int AutomaticResponses { get; set; }
        public int Orders { get; set; }
        public short IssuesRaised { get; set; }
        public short AverageTimePerIssue { get; set; }
        public double ServiceGrade { get; set; }
        [Column(TypeName = "datetime")]
        public DateTime? Date { get; set; }

        [ForeignKey("DateKey")]
        [InverseProperty("FactCallCenters")]
        public virtual DimDate DateKeyNavigation { get; set; } = null!;
    }
}
