﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using Microsoft.EntityFrameworkCore;

namespace CSharpEF.AdventureWorks.Models
{
    [Keyless]
    public partial class VAssocSeqOrder
    {
        [StringLength(20)]
        public string OrderNumber { get; set; } = null!;
        public int CustomerKey { get; set; }
        [StringLength(50)]
        public string? Region { get; set; }
        [StringLength(8)]
        [Unicode(false)]
        public string IncomeGroup { get; set; } = null!;
    }
}
