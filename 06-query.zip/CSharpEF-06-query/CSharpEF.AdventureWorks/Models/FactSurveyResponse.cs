﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using Microsoft.EntityFrameworkCore;

namespace CSharpEF.AdventureWorks.Models
{
    [Table("FactSurveyResponse")]
    public partial class FactSurveyResponse
    {
        [Key]
        public int SurveyResponseKey { get; set; }
        public int DateKey { get; set; }
        public int CustomerKey { get; set; }
        public int ProductCategoryKey { get; set; }
        [StringLength(50)]
        public string EnglishProductCategoryName { get; set; } = null!;
        public int ProductSubcategoryKey { get; set; }
        [StringLength(50)]
        public string EnglishProductSubcategoryName { get; set; } = null!;
        [Column(TypeName = "datetime")]
        public DateTime? Date { get; set; }

        [ForeignKey("CustomerKey")]
        [InverseProperty("FactSurveyResponses")]
        public virtual DimCustomer CustomerKeyNavigation { get; set; } = null!;
        [ForeignKey("DateKey")]
        [InverseProperty("FactSurveyResponses")]
        public virtual DimDate DateKeyNavigation { get; set; } = null!;
    }
}
