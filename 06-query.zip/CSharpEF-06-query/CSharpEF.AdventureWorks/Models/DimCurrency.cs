﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using Microsoft.EntityFrameworkCore;

namespace CSharpEF.AdventureWorks.Models
{
    [Table("DimCurrency")]
    [Index("CurrencyAlternateKey", Name = "AK_DimCurrency_CurrencyAlternateKey", IsUnique = true)]
    public partial class DimCurrency
    {
        public DimCurrency()
        {
            DimOrganizations = new HashSet<DimOrganization>();
            FactCurrencyRates = new HashSet<FactCurrencyRate>();
            FactInternetSales = new HashSet<FactInternetSale>();
            FactResellerSales = new HashSet<FactResellerSale>();
        }

        [Key]
        public int CurrencyKey { get; set; }
        [StringLength(3)]
        public string CurrencyAlternateKey { get; set; } = null!;
        [StringLength(50)]
        public string CurrencyName { get; set; } = null!;

        [InverseProperty("CurrencyKeyNavigation")]
        public virtual ICollection<DimOrganization> DimOrganizations { get; set; }
        [InverseProperty("CurrencyKeyNavigation")]
        public virtual ICollection<FactCurrencyRate> FactCurrencyRates { get; set; }
        [InverseProperty("CurrencyKeyNavigation")]
        public virtual ICollection<FactInternetSale> FactInternetSales { get; set; }
        [InverseProperty("CurrencyKeyNavigation")]
        public virtual ICollection<FactResellerSale> FactResellerSales { get; set; }
    }
}
