﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using Microsoft.EntityFrameworkCore;

namespace CSharpEF.AdventureWorks.Models
{
    [Keyless]
    [Table("FactFinance")]
    public partial class FactFinance
    {
        public int FinanceKey { get; set; }
        public int DateKey { get; set; }
        public int OrganizationKey { get; set; }
        public int DepartmentGroupKey { get; set; }
        public int ScenarioKey { get; set; }
        public int AccountKey { get; set; }
        public double Amount { get; set; }
        [Column(TypeName = "datetime")]
        public DateTime? Date { get; set; }

        [ForeignKey("AccountKey")]
        public virtual DimAccount AccountKeyNavigation { get; set; } = null!;
        [ForeignKey("DateKey")]
        public virtual DimDate DateKeyNavigation { get; set; } = null!;
        [ForeignKey("DepartmentGroupKey")]
        public virtual DimDepartmentGroup DepartmentGroupKeyNavigation { get; set; } = null!;
        [ForeignKey("OrganizationKey")]
        public virtual DimOrganization OrganizationKeyNavigation { get; set; } = null!;
        [ForeignKey("ScenarioKey")]
        public virtual DimScenario ScenarioKeyNavigation { get; set; } = null!;
    }
}
