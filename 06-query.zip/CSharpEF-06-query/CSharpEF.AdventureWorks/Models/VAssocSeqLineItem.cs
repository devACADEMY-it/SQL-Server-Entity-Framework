﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using Microsoft.EntityFrameworkCore;

namespace CSharpEF.AdventureWorks.Models
{
    [Keyless]
    public partial class VAssocSeqLineItem
    {
        [StringLength(20)]
        public string OrderNumber { get; set; } = null!;
        public byte LineNumber { get; set; }
        [StringLength(50)]
        public string? Model { get; set; }
    }
}
