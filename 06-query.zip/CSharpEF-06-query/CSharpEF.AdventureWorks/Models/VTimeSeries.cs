﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using Microsoft.EntityFrameworkCore;

namespace CSharpEF.AdventureWorks.Models
{
    [Keyless]
    public partial class VTimeSeries
    {
        [StringLength(56)]
        public string? ModelRegion { get; set; }
        public int? TimeIndex { get; set; }
        public int? Quantity { get; set; }
        [Column(TypeName = "money")]
        public decimal? Amount { get; set; }
        public short CalendarYear { get; set; }
        public byte Month { get; set; }
        [Column(TypeName = "datetime")]
        public DateTime? ReportingDate { get; set; }
    }
}
