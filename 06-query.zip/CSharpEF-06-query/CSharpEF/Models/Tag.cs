﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

// 06-08 APPROCCIO FLUENT
namespace CSharpEF.Models
{
    public class Tag
    {
        public string? Id { get; set; }

        public virtual ICollection<Articolo>? Articoli { get; set; }
        public virtual ICollection<ArticoloTag>? ArticoloTags { get; set; }
    }

    public class ArticoloTag
    {
        public DateTime DataAssociazione { get; set; }

        public int ArticoloId { get; set; }
        public virtual Articolo? Articolo { get; set; }

        public string? TagId { get; set; }
        public virtual Tag? Tag { get; set; }
    }
}
