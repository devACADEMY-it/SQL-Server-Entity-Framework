﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

// 05-01 CREAZIONE MODELLI
namespace CSharpEF.Models
{
    public class Articolo
    {
        // Id = Convenzione Chiave Primaria
        public int Id { get; set; }

        // 05-03 ANNOTAZIONI
        [Required]
        [MaxLength(100)]
        public string? Titolo { get; set; }

        [Required]
        public string? Testo { get; set; }

        [Required]
        public virtual Utente? Autore { get; set; }

        public virtual ICollection<Commento>? Commenti { get; set; }

        // 06-07 RELAZIONE MOLTI A MOLTI
        public virtual ICollection<Categoria>? Categorie { get; set; }

        // 06-08 APPROCCIO FLUENT
        public virtual ICollection<Tag>? Tags { get; set; }

        public virtual ICollection<ArticoloTag>? ArticoloTags { get; set; }
    }
}
