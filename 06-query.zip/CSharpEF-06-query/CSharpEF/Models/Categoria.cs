﻿using System.ComponentModel.DataAnnotations;

// 05-01 CREAZIONE MODELLI
namespace CSharpEF.Models
{
    public class Categoria
    {      
        public int Id { get; set; }

        // 05-03 ANNOTAZIONI
        [Required]
        [MaxLength(100)]
        public string? Nome { get; set; }

        // 06-07 RELAZIONE MOLTI A MOLTI
        public virtual ICollection<Articolo>? Articoli { get; set; }
    }
}
