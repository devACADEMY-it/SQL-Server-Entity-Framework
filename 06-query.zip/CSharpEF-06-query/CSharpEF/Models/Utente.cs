﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

// 05-01 CREAZIONE MODELLI
namespace CSharpEF.Models
{
    public class Utente
    {
        public int Id { get; set; }

        // 05-03 ANNOTAZIONI
        [Required]
        public string? Nome { get; set; }

        // 06-06 NAVIGATION PROPERTIES
        [InverseProperty("Autore")]
        public virtual ICollection<Articolo>? Articoli { get; set; }

        [InverseProperty("Autore")]
        public virtual ICollection<Commento>? Commenti { get; set; }
    }
}
