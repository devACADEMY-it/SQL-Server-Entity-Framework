﻿using CSharpEF;
using CSharpEF.AdventureWorks;
using CSharpEF.Models;
using Microsoft.Data.SqlClient;
using Microsoft.EntityFrameworkCore;
using System.Data;

// script azzeramento
// cancellare il DB e ricrearlo con la singola migrazione

/*
DELETE FROM ArticoloCategoria;
DELETE FROM ArticoloTag;
DELETE FROM Commenti;
DELETE FROM Categorie;
DELETE FROM Tags;
DELETE FROM Articoli;
DELETE FROM Utenti;
DBCC CHECKIDENT ('Commenti', RESEED, 0);  
DBCC CHECKIDENT ('Categorie', RESEED, 0); 
DBCC CHECKIDENT ('Articoli', RESEED, 0); 
DBCC CHECKIDENT ('Utenti', RESEED, 0);  

oppure

cancellare database da SSMS e rilanciare:
dotnet ef database update
*/
Console.OutputEncoding = System.Text.Encoding.UTF8;
// 06-01 INTRODUZIONE
// anatomia di una query
// logging
// le query vengono effettivamente eseguite
// nel momento in cui accediamo ai dati
// es: foreach, Count(), Min(), First(), ToList()
using (var dc = new BlogContext())
{
    var data = dc.Articoli.Where(x => x.Id > 0);
    // data.ToList();
}

// 06-02 SELEZIONE
// rivedere lezione 04-03 per l'importazione di AdevntureWorks
// lazy loading, notracking
using (var dc = new AdventureWorksDW2019Context())
{
    // AsNoTracking() aumenta le performance quando facciamo query in sola lettura
    var data = dc.DimProducts.AsNoTracking().Where(x => x.ListPrice > 2000);
    foreach (var item in data)
    {
        Console.WriteLine($"{item.EnglishProductName} - {item.ListPrice:c}");
    }
    Console.WriteLine();

    // eager loading, lazy loading
    // disabilitare .UseLazyLoadingProxies() nel DbContext
    var prodotti = dc.DimProducts.AsQueryable();
    prodotti = prodotti
        .Include(p => p.ProductSubcategoryKeyNavigation)
        .Where(x => x.ProductSubcategoryKeyNavigation!.EnglishProductSubcategoryName == "Pedals");

    foreach (var item in prodotti.ToList())
    {
        Console.WriteLine($"{item.ProductSubcategoryKeyNavigation?.EnglishProductSubcategoryName} - {item.EnglishProductName}");
    }
    Console.WriteLine();

    prodotti = prodotti
        .Include(p => p.ProductSubcategoryKeyNavigation)
        .ThenInclude(p => p!.ProductCategoryKeyNavigation)
        .Where(x => x.ProductSubcategoryKeyNavigation!.EnglishProductSubcategoryName == "Pedals");

    foreach (var item in prodotti.ToList())
    {
        Console.WriteLine($"{item.ProductSubcategoryKeyNavigation?.ProductCategoryKeyNavigation?.EnglishProductCategoryName} - {item.ProductSubcategoryKeyNavigation?.EnglishProductSubcategoryName} - {item.EnglishProductName}");
    }
    Console.WriteLine();
}

//// 06-03 CREATE 1
//using (var dc = new BlogContext())
//{
//    var u = new Utente() { Nome = "Gigi Rossi" };
//    dc.Utenti.Add(u);

//    var u2 = new Utente() { Nome = "Hater" };
//    dc.Utenti.Add(u2);

//    // simulazione errore
//    // disabilitare logging nel BlogContext
//    //var c = new Categoria();
//    var c = new Categoria() { Nome = "Cucina" };
//    dc.Categorie.Add(c);

//// 06-04 CREATE 2
//    var t = new Tag() { Id = "NUOVO" };
//    dc.Tags.Add(t);

//    var a = new Articolo
//    {
//        Autore = u,
//        Titolo = "Spaghetti alle vongole",
//        Testo = "Spaghetti alle vongole",
//        Categorie = new List<Categoria> { c },
//        Tags = new List<Tag> { t }
//    };

//    var a2 = new Articolo
//    {
//        Autore = u,
//        Titolo = "Frittata",
//        Testo = "Frittata",
//        Categorie = new List<Categoria> { c },
//        Tags = new List<Tag> { t },
//        Commenti = new List<Commento>
//        {
//            new Commento { Autore = u, Testo = "Buona" },
//            new Commento { Autore = u2, Testo = "La faccio meglio io!" },
//            new Commento { Autore = u2, Testo = "Cattivissima!" }
//        }
//    };
//    dc.Articoli.AddRange(a, a2);

//    try
//    {
//        dc.SaveChanges();
//    }
//    catch (Exception ex)
//    {
//        Console.WriteLine(ex.InnerException?.Message);
//    }
//}

// 06-05 UPDATE E DELETE
// commentare CREATE
using (var dc = new BlogContext())
{
    var u = dc.Utenti.First(x => x.Nome!.StartsWith("Gigi"));
    var a = dc.Articoli.First(a => a.Autore == u);
    a.Titolo = a.Titolo + " [AGGIORNATO]";

    try
    {
        dc.SaveChanges();
    }
    catch (Exception ex)
    {
        Console.WriteLine(ex.InnerException?.Message);
    }

#nullable disable
    var commentiBrutti = dc.Articoli
                           .Include(i => i.Commenti)
                           .ThenInclude(i => i.Autore)
                           .Single(x => x.Id == 2).Commenti.Where(x => x.Autore.Nome == "Hater");
    dc.Commenti.RemoveRange(commentiBrutti);

    try
    {
        dc.SaveChanges();
    }
    catch (Exception ex)
    {
        Console.WriteLine(ex.InnerException?.Message);
    }


    // Istruzioni SQL
    try
    {
        dc.Database.ExecuteSqlRaw("UPDATE Articoli SET Testo = '[REVISIONATO] ' + Testo");
    }
    catch (Exception ex)
    {
        Console.WriteLine(ex.InnerException?.Message);
    }
}

// 06-06 STORED PROCEDURES
// 1. creare migration
// dotnet ef migrations add StoredProcedures
// 2. aggiungere gli script in StoredProcedures.sql
// 3. aggiornare database
// dotnet ef database update
using (var dc = new BlogContext())
{
    var autoreIdParam = new SqlParameter("@AutoreId", 1);

    var articoli = dc.Articoli.FromSqlRaw("exec GetArticoliByAutore @AutoreId", autoreIdParam).ToList();

    foreach (var item in articoli)
    {
        Console.WriteLine(item.Titolo);
    }
}

using (var dc = new BlogContext())
{
    var titoloParam = new SqlParameter("@Titolo", "Caprese");
    var testoParam = new SqlParameter("@Testo", "Caprese testo");
    var autoreIdParam = new SqlParameter("@AutoreId", 1);
    var articoloIdParam = new SqlParameter("@ArticoloId", SqlDbType.Int);
    articoloIdParam.Direction = ParameterDirection.Output;

    var articoli = dc.Database.ExecuteSqlRaw(
            "exec InsertArticolo @Titolo, @Testo, @AutoreId, @ArticoloId out",
            titoloParam,
            testoParam,
            autoreIdParam,
            articoloIdParam);

    Console.WriteLine(articoloIdParam.Value);
}
Console.ReadKey();
