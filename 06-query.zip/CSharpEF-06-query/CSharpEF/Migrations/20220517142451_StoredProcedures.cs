﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace CSharpEF.Migrations
{
    public partial class StoredProcedures : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.Sql(@"
                CREATE OR ALTER PROCEDURE [dbo].[InsertArticolo] 
	                @Titolo nvarchar(100) = '', 
	                @Testo nvarchar(MAX) = '', 
	                @AutoreId int,
	                @ArticoloId int output
                AS
                BEGIN
	                INSERT INTO Articoli VALUES (@Titolo, @Testo, @AutoreId);
	                SET @ArticoloId=SCOPE_IDENTITY();
                END                
            ");

            migrationBuilder.Sql(@"
                CREATE OR ALTER PROCEDURE [dbo].[GetArticoliByAutore]
                    @AutoreId int
                AS
                BEGIN
                    SELECT* FROM Articoli WHERE AutoreId = @AutoreId;
                END              
            ");

            
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.Sql("DROP PROCEDURE [dbo].[InsertArticolo]");
            migrationBuilder.Sql("DROP PROCEDURE [dbo].[GetArticoliByAutore]");
        }
    }
}
