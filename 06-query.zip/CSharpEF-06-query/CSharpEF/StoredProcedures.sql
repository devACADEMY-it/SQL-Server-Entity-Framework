﻿CREATE OR ALTER PROCEDURE [dbo].[InsertArticolo] 
	@Titolo nvarchar(100) = '', 
	@Testo nvarchar(MAX) = '', 
	@AutoreId int,
	@ArticoloId int output
AS
BEGIN
	INSERT INTO Articoli VALUES (@Titolo, @Testo, @AutoreId);
	SET @ArticoloId=SCOPE_IDENTITY();
END

CREATE OR ALTER PROCEDURE [dbo].[GetArticoliByAutore] 
	@AutoreId int
AS
BEGIN
	SELECT * FROM Articoli WHERE AutoreId = @AutoreId;
END