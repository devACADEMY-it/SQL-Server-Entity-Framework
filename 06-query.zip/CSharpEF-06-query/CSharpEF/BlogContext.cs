﻿using System;
using System.Collections.Generic;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata;
using CSharpEF.Models;
using System.Linq;

// 05-01 CREAZIONE MODELLI
namespace CSharpEF
{
    public partial class BlogContext : DbContext
    {
        public BlogContext()
        {


        }

        public BlogContext(DbContextOptions<BlogContext> options)
            : base(options)
        {

        }

        public DbSet<Utente> Utenti { get { return base.Set<Utente>(); } }

        // get abbreviata
        public DbSet<Categoria> Categorie => Set<Categoria>();
        public DbSet<Articolo> Articoli => Set<Articolo>();
        public DbSet<Commento> Commenti => Set<Commento>();

        public DbSet<Tag> Tags => Set<Tag>();

        // 05-04 ANNOTAZIONI 2
        //public DbSet<CategoriaProdotto> CategorieProdotto => Set<CategoriaProdotto>();
        //public DbSet<Prodotto> Prodotti => Set<Prodotto>();


        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            if (!optionsBuilder.IsConfigured)
            {
                optionsBuilder
                    //.UseLazyLoadingProxies()
                    .UseSqlServer("Data Source=(localdb)\\MSSQLLocalDB;Initial Catalog=CSharpEF_Blog;User Id=sa;Password=sa");
                    //.LogTo(Console.WriteLine, Microsoft.Extensions.Logging.LogLevel.Information); // logging
            }
        }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<Articolo>()
                .HasMany(a => a.Tags)
                .WithMany(t => t.Articoli)
                .UsingEntity<ArticoloTag>(
                    j => j
                        .HasOne(t => t.Tag)
                        .WithMany(t => t.ArticoloTags)
                        .HasForeignKey(f => f.TagId),
                    j => j
                        .HasOne(a => a.Articolo)
                        .WithMany(a => a.ArticoloTags)
                        .HasForeignKey(f => f.ArticoloId),
                    j =>
                    {
                        j.Property(p => p.DataAssociazione).HasDefaultValueSql("getdate()");
                        j.HasKey(k => new { k.TagId, k.ArticoloId });
                    });

            OnModelCreatingPartial(modelBuilder);
        }

        partial void OnModelCreatingPartial(ModelBuilder modelBuilder);
    }
}
