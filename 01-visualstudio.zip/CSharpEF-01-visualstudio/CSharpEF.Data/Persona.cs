﻿namespace CSharpEF.Data
{
    public class Persona
    {
        public string? Nome { get; set; }
    }
}